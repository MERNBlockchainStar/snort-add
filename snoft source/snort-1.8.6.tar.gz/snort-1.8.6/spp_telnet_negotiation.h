/*
** Copyright (C) 1998-2002 Martin Roesch <roesch@sourcefire.com>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

/* $Id: spp_telnet_negotiation.h,v 1.2.4.1 2002/03/15 14:42:32 chrisgreen Exp $ */

/* Snort Preprocessor Telnet Negotiation Normalization */

#include "snort.h"

#ifndef __SPP_TEL_NEG_H__
#define __SPP_TEL_NEG_H__

/* define the telnet negotiation codes (TNC) that we're interested in */
#define TNC_IAC  0xFF
#define TNC_SB   0xFA
#define TNC_NOP  0xF1
#define TNC_SE   0xF0

#define TNC_STD_LENGTH  3

/* list of function prototypes for this preprocessor */
extern void SetupTelNeg();
extern void TelNegInit(u_char *);
extern void NormalizeTelnet(Packet *);


#endif  /* __SPP_TEL_NEG_H__ */
