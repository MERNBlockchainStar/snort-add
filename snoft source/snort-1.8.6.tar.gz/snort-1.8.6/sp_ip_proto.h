/* $Id: sp_ip_proto.h,v 1.1 2001/04/16 02:13:14 roesch Exp $ */

#ifndef __SP_IP_PROTO_H__
#define __SP_IP_PROTO_H__

#include "snort.h"

#define PLUGIN_IP_PROTO_CHECK  25

typedef struct _IpProtoData
{
    u_int8_t protocol;
    u_int8_t not_flag;

} IpProtoData;

void IpProtoInit(char *, OptTreeNode *, int);
void SetupIpProto();
void IpProtoRuleParseFunction(char *, OptTreeNode *);
int IpProtoDetectorFunction(Packet *, struct _OptTreeNode *, OptFpList *);

#endif  /* __SP_IP_PROTO_H__ */
