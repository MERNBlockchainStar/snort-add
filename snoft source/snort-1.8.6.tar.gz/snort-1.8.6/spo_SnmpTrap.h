/* $Id: spo_SnmpTrap.h,v 1.2 2001/07/30 05:43:51 roesch Exp $ */
#ifdef ENABLE_SNMP
#include "snort.h"

#ifndef __SPO_SNMPTRAP_H__
#define __SPO_SNMPTRAP_H__

/* list of function prototypes for this preprocessor */
void SnmpTrapInit(u_char *);
void SetupSnmpTrap();
void SnmpTrapCleanExitFunc(int, void *);
void SnmpTrapRestartFunc(int, void *);
void SpoSnmpTrap(Packet *, char *, void *, Event *event);

#endif  /* __SPO_SNMPTRAP_H__ */
#endif
