/* $Id: generators.h,v 1.9.2.4 2002/03/15 14:42:30 chrisgreen Exp $ */
/*
** Copyright (C) 1998-2002 Martin Roesch <roesch@sourcefire.com>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef __GENERATORS_H__
#define __GENERATORS_H__

#define GENERATOR_SNORT_ENGINE        1

#define GENERATOR_TAG                 2
#define    TAG_LOG_PKT                1

#define GENERATOR_SPP_PORTSCAN      100
#define     PORTSCAN_SCAN_DETECT        1
#define     PORTSCAN_INTER_INFO         2
#define     PORTSCAN_SCAN_END           3

#define GENERATOR_SPP_MINFRAG       101
#define     MINFRAG_ALERT_ID            1

#define GENERATOR_SPP_HTTP_DECODE   102
#define     HTTP_DECODE_UNICODE_ATTACK  1
#define     HTTP_DECODE_CGINULL_ATTACK  2

#define GENERATOR_SPP_DEFRAG        103
#define     DEFRAG_FRAG_OVERFLOW        1
#define     DEFRAG_FRAGS_DISCARDED      2

#define GENERATOR_SPP_SPADE         104
#define     SPADE_ANOM_THRESHOLD_EXCEEDED   1
#define     SPADE_ANOM_THRESHOLD_ADJUSTED   2

#define GENERATOR_SPP_BO            105
#define     BO_TRAFFIC_DETECT           1

#define GENERATOR_SPP_RPC_DECODE    106
#define GENERATOR_SPP_STREAM2       107
#define GENERATOR_SPP_STREAM3       108
#define GENERATOR_SPP_TELNET_NEG    109

#define GENERATOR_SPP_UNIDECODE     110
#define     UNIDECODE_CGINULL_ATTACK        1
#define     UNIDECODE_DIRECTORY_TRAVERSAL   2
#define     UNIDECODE_UNKNOWN_MAPPING       3
#define     UNIDECODE_INVALID_MAPPING       4

#define GENERATOR_SPP_STREAM4       111
#define     STREAM4_STEALTH_ACTIVITY            1
#define     STREAM4_EVASIVE_RST                 2
#define     STREAM4_EVASIVE_RETRANS             3
#define     STREAM4_WINDOW_VIOLATION            4
#define     STREAM4_DATA_ON_SYN                 5
#define     STREAM4_STEALTH_FULL_XMAS           6
#define     STREAM4_STEALTH_SAPU                7
#define     STREAM4_STEALTH_FIN_SCAN            8
#define     STREAM4_STEALTH_NULL_SCAN           9
#define     STREAM4_STEALTH_NMAP_XMAS_SCAN      10
#define     STREAM4_STEALTH_VECNA_SCAN          11
#define     STREAM4_STEALTH_NMAP_FINGERPRINT    12
#define     STREAM4_STEALTH_SYN_FIN_SCAN        13
#define     STREAM4_FORWARD_OVERLAP             14

#define GENERATOR_SPP_ARPSPOOF      112
#define     ARPSPOOF_UNICAST_ARP_REQUEST         1
#define     ARPSPOOF_ETHERFRAME_ARP_MISMATCH_SRC  2
#define     ARPSPOOF_ETHERFRAME_ARP_MISMATCH_DST  3
#define     ARPSPOOF_ARP_CACHE_OVERWRITE_ATTACK   4

#define GENERATOR_SPP_FRAG2         113
#define     FRAG2_OVERSIZE_FRAG                   1
#define     FRAG2_TEARDROP                        2

#define GENERATOR_SPP_FNORD         114
#define     FNORD_NOPSLED                         1

#define GENERATOR_SPP_ASN1          115
#define     ASN1_INDEFINITE_LENGTH                1
#define     ASN1_INVALID_LENGTH                   2
#define     ASN1_OVERSIZED_ITEM                   3
#define     ASN1_SPEC_VIOLATION                   4
#define     ASN1_DATUM_BAD_LENGTH                 5

#endif /* __GENERATORS_H__ */
